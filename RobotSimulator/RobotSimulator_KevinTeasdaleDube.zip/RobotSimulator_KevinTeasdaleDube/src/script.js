/** Voir dans le HTML malheureusement par manque de temps
 * 
 * 2018-12-13
 * Kevin Teasdale-Dubé
 */

 